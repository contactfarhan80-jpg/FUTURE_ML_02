const API_BASE = "http://localhost:5001/api";

const trainBtn = document.getElementById("trainBtn");
const trainStatus = document.getElementById("trainStatus");
const trainMetrics = document.getElementById("trainMetrics");
const classifyBtn = document.getElementById("classifyBtn");
const classifyStatus = document.getElementById("classifyStatus");
const ticketText = document.getElementById("ticketText");
const resultCard = document.getElementById("resultCard");
const sampleTicketsEl = document.getElementById("sampleTickets");

trainBtn.addEventListener("click", trainModels);
classifyBtn.addEventListener("click", classifyTicket);

loadSampleTickets();

async function trainModels() {
  trainStatus.textContent = "Training models on sample data...";
  trainBtn.disabled = true;
  try {
    const res = await fetch(`${API_BASE}/train`, { method: "POST", headers: { "Content-Type": "application/json" }, body: "{}" });
    const json = await res.json();
    if (json.error) throw new Error(json.error);
    trainStatus.textContent = "✅ Models trained successfully.";
    renderTrainMetrics(json.metrics);
  } catch (err) {
    trainStatus.textContent = `Error: ${err.message}. Is the backend running on port 5001?`;
  } finally {
    trainBtn.disabled = false;
  }
}

function renderTrainMetrics(metrics) {
  trainMetrics.innerHTML = "";
  Object.entries(metrics).forEach(([target, m]) => {
    const box = document.createElement("div");
    box.className = "metric-box";
    box.innerHTML = `
      <h4>${target} classifier</h4>
      <p>Accuracy: ${(m.accuracy * 100).toFixed(1)}%</p>
      <p>F1 (weighted): ${m.f1_weighted}</p>
      <p>Train/Test: ${m.n_train}/${m.n_test}</p>
    `;
    trainMetrics.appendChild(box);
  });
  trainMetrics.style.display = "grid";
}

async function classifyTicket() {
  const text = ticketText.value.trim();
  if (!text) {
    classifyStatus.textContent = "Please enter some ticket text.";
    return;
  }
  classifyStatus.textContent = "Classifying...";
  try {
    const res = await fetch(`${API_BASE}/classify`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ text }),
    });
    const json = await res.json();
    if (json.error) throw new Error(json.error);
    renderResult(json);
    classifyStatus.textContent = "";
  } catch (err) {
    classifyStatus.textContent = `Error: ${err.message}`;
  }
}

function renderResult(json) {
  resultCard.style.display = "block";
  document.getElementById("categoryLabel").textContent = json.category.label;
  document.getElementById("categoryConfidence").textContent = `Confidence: ${(json.category.confidence * 100).toFixed(1)}%`;

  const priorityLabelEl = document.getElementById("priorityLabel");
  priorityLabelEl.textContent = json.priority.label;
  priorityLabelEl.style.color = { High: "#dc2626", Medium: "#d97706", Low: "#16a34a" }[json.priority.label] || "#1f2333";
  document.getElementById("priorityConfidence").textContent = `Confidence: ${(json.priority.confidence * 100).toFixed(1)}%`;

  const urgencyNote = document.getElementById("urgencyNote");
  if (json.priority.urgency_keywords_detected && json.priority.urgency_keywords_detected.length) {
    urgencyNote.textContent = `⚠️ Urgency signals detected: ${json.priority.urgency_keywords_detected.join(", ")}`;
  } else {
    urgencyNote.textContent = "";
  }

  const distEl = document.getElementById("distribution");
  distEl.innerHTML = "<strong>Category distribution</strong>";
  Object.entries(json.category.distribution).forEach(([label, prob]) => {
    distEl.appendChild(makeDistRow(label, prob));
  });
  const priHeader = document.createElement("strong");
  priHeader.textContent = "Priority distribution";
  priHeader.style.marginTop = "10px";
  priHeader.style.display = "block";
  distEl.appendChild(priHeader);
  Object.entries(json.priority.distribution).forEach(([label, prob]) => {
    distEl.appendChild(makeDistRow(label, prob));
  });
}

function makeDistRow(label, prob) {
  const row = document.createElement("div");
  row.className = "dist-row";
  row.innerHTML = `
    <span style="width:90px;">${label}</span>
    <div class="dist-bar-bg"><div class="dist-bar-fill" style="width:${(prob * 100).toFixed(0)}%"></div></div>
    <span>${(prob * 100).toFixed(0)}%</span>
  `;
  return row;
}

async function loadSampleTickets() {
  try {
    const res = await fetch(`${API_BASE}/sample-data`);
    const json = await res.json();
    sampleTicketsEl.innerHTML = "";
    json.data.slice(0, 6).forEach((row) => {
      const div = document.createElement("div");
      div.className = "sample-item";
      div.textContent = row.text;
      div.addEventListener("click", () => { ticketText.value = row.text; });
      sampleTicketsEl.appendChild(div);
    });
  } catch (err) {
    sampleTicketsEl.innerHTML = `<p class="muted">Backend not reachable yet. Start it on port 5001.</p>`;
  }
}
