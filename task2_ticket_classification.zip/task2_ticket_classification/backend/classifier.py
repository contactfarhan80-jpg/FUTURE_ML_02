"""
Support Ticket Classification - core NLP + ML module.

Pipeline
--------
1. Text preprocessing: lowercase, strip punctuation/URLs/numbers, remove
   stopwords, (optional) lemmatize with NLTK if its data is available -
   falls back gracefully to a lightweight regex-based cleaner otherwise so
   the project still runs with zero extra downloads.
2. Feature extraction: TF-IDF over unigrams + bigrams.
3. Two classifiers trained on the same features:
      - category classifier   (Account / Billing / Technical / General)
      - priority classifier   (High / Medium / Low)
   Both use LinearSVC wrapped in CalibratedClassifierCV so we can expose
   probability-like confidence scores to the frontend.
4. Simple keyword-based priority booster: tickets containing urgency signals
   ("urgent", "immediately", "down", "cannot log in", etc.) are nudged toward
   High priority even if the ML model is unsure - mirrors how real support
   teams triage.

Everything is trained in-memory and cached to disk (joblib) so the Flask app
only retrains when the sample/uploaded dataset changes.
"""

import os
import re
import string

import joblib
import pandas as pd
from sklearn.calibration import CalibratedClassifierCV
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, f1_score
from sklearn.pipeline import Pipeline
from sklearn.svm import LinearSVC

try:
    import nltk
    from nltk.corpus import stopwords

    STOPWORDS = set(stopwords.words("english"))
except Exception:  # noqa: BLE001 - nltk data not downloaded, use fallback
    STOPWORDS = {
        "the", "a", "an", "is", "are", "was", "were", "be", "been", "to", "of",
        "and", "in", "on", "for", "with", "this", "that", "it", "i", "my",
        "me", "you", "your", "please", "can", "would", "could", "at", "as",
        "so", "but", "or", "if", "not", "do", "does", "did", "have", "has",
        "had", "will", "shall", "am", "we", "us", "our",
    }

URGENCY_WORDS = {
    "urgent", "urgently", "immediately", "asap", "down", "crashed", "crash",
    "broken", "cannot", "can't", "unable", "emergency", "critical", "outage",
}

MODEL_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "trained_models")
os.makedirs(MODEL_DIR, exist_ok=True)
CATEGORY_MODEL_PATH = os.path.join(MODEL_DIR, "category_model.joblib")
PRIORITY_MODEL_PATH = os.path.join(MODEL_DIR, "priority_model.joblib")


def clean_text(text: str) -> str:
    """Lowercase, strip URLs/punctuation/numbers, remove stopwords."""
    text = str(text).lower()
    text = re.sub(r"http\S+|www\.\S+", " ", text)
    text = text.translate(str.maketrans("", "", string.punctuation))
    text = re.sub(r"\d+", " ", text)
    tokens = [t for t in text.split() if t not in STOPWORDS and len(t) > 1]
    return " ".join(tokens)


def _build_pipeline():
    return Pipeline([
        ("tfidf", TfidfVectorizer(ngram_range=(1, 2), min_df=1, max_df=0.95)),
        ("clf", CalibratedClassifierCV(LinearSVC(), cv=3)),
    ])


def train_models(df: pd.DataFrame):
    """
    df must contain columns: text, category, priority
    Returns evaluation metrics for both classifiers.
    """
    df = df.dropna(subset=["text", "category", "priority"]).copy()
    df["clean_text"] = df["text"].apply(clean_text)

    metrics = {}

    for target, path in [("category", CATEGORY_MODEL_PATH), ("priority", PRIORITY_MODEL_PATH)]:
        X_train, X_test, y_train, y_test = train_test_split(
            df["clean_text"], df[target], test_size=0.25, random_state=42,
            stratify=df[target] if df[target].nunique() > 1 else None,
        )
        pipeline = _build_pipeline()
        pipeline.fit(X_train, y_train)
        preds = pipeline.predict(X_test)
        metrics[target] = {
            "accuracy": round(accuracy_score(y_test, preds), 3),
            "f1_weighted": round(f1_score(y_test, preds, average="weighted"), 3),
            "n_train": len(X_train),
            "n_test": len(X_test),
            "classes": sorted(df[target].unique().tolist()),
        }
        # refit on full data for production use
        pipeline.fit(df["clean_text"], df[target])
        joblib.dump(pipeline, path)

    return metrics


def _load_models():
    if not (os.path.exists(CATEGORY_MODEL_PATH) and os.path.exists(PRIORITY_MODEL_PATH)):
        return None, None
    return joblib.load(CATEGORY_MODEL_PATH), joblib.load(PRIORITY_MODEL_PATH)


def classify_ticket(text: str):
    category_model, priority_model = _load_models()
    if category_model is None:
        raise RuntimeError("Models are not trained yet. Call /api/train first.")

    cleaned = clean_text(text)

    cat_pred = category_model.predict([cleaned])[0]
    cat_proba = category_model.predict_proba([cleaned])[0]
    cat_confidence = float(max(cat_proba))
    cat_classes = category_model.classes_

    pri_pred = priority_model.predict([cleaned])[0]
    pri_proba = priority_model.predict_proba([cleaned])[0]
    pri_confidence = float(max(pri_proba))
    pri_classes = priority_model.classes_

    # keyword-based priority boost
    lowered = text.lower()
    urgency_hits = [w for w in URGENCY_WORDS if w in lowered]
    if urgency_hits and pri_pred != "High":
        pri_pred = "High"
        pri_confidence = max(pri_confidence, 0.75)

    return {
        "category": {
            "label": cat_pred,
            "confidence": round(cat_confidence, 3),
            "distribution": {cls: round(float(p), 3) for cls, p in zip(cat_classes, cat_proba)},
        },
        "priority": {
            "label": pri_pred,
            "confidence": round(pri_confidence, 3),
            "distribution": {cls: round(float(p), 3) for cls, p in zip(pri_classes, pri_proba)},
            "urgency_keywords_detected": urgency_hits,
        },
        "cleaned_text": cleaned,
    }


def models_ready() -> bool:
    return os.path.exists(CATEGORY_MODEL_PATH) and os.path.exists(PRIORITY_MODEL_PATH)
