"""
Support Ticket Classification - Flask backend.

Endpoints
---------
GET  /api/health            -> health check
GET  /api/sample-data       -> bundled sample ticket dataset
POST /api/train             -> trains category + priority classifiers.
                                Body (optional): {"data": [{"text":..,"category":..,"priority":..}]}
                                If omitted, trains on the bundled sample dataset.
POST /api/classify          -> body: {"text": "..."} returns category, priority, confidence
"""

import os

import pandas as pd
from flask import Flask, jsonify, request
from flask_cors import CORS

from classifier import classify_ticket, models_ready, train_models

app = Flask(__name__)
CORS(app)

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
SAMPLE_PATH = os.path.join(BASE_DIR, "sample_data", "tickets.csv")


@app.get("/api/health")
def health():
    return jsonify({"status": "ok", "service": "ticket-classification-api", "models_ready": models_ready()})


@app.get("/api/sample-data")
def sample_data():
    df = pd.read_csv(SAMPLE_PATH)
    return jsonify({"data": df.to_dict(orient="records")})


@app.post("/api/train")
def train():
    payload = request.get_json(force=True, silent=True) or {}
    records = payload.get("data")

    df = pd.DataFrame(records) if records else pd.read_csv(SAMPLE_PATH)

    required_cols = {"text", "category", "priority"}
    if not required_cols.issubset(df.columns):
        return jsonify({"error": f"Data must include columns: {sorted(required_cols)}"}), 400

    try:
        metrics = train_models(df)
        return jsonify({"message": "Models trained successfully.", "metrics": metrics})
    except Exception as exc:  # noqa: BLE001
        return jsonify({"error": str(exc)}), 400


@app.post("/api/classify")
def classify():
    payload = request.get_json(force=True, silent=True) or {}
    text = payload.get("text", "").strip()

    if not text:
        return jsonify({"error": "Field 'text' is required."}), 400

    if not models_ready():
        # auto-train on the sample dataset the first time, for convenience
        df = pd.read_csv(SAMPLE_PATH)
        train_models(df)

    try:
        result = classify_ticket(text)
        return jsonify(result)
    except Exception as exc:  # noqa: BLE001
        return jsonify({"error": str(exc)}), 400


if __name__ == "__main__":
    app.run(debug=True, port=5001)
